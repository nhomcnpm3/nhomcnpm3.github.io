# WebRTC - Video Call with SocketIO Nodejs

[![N|Solid](https://1.bp.blogspot.com/-8oBd42OoT48/YJaAEIrtm1I/AAAAAAAACz0/bP_sBzQoSxsxQytUaCLpm4rPXpIZ_kwCgCNcBGAsYHQ/s712/webRTC-SocketIO-Node.png)](https://www.bloggernepal.com/2021/05/webrtc-video-call-with-socketio-nodejs.html)

A Introduction to WebRTC and Guide on creating a Video Call Application with WebRTC using SocketIO and Nodejs.

Guide on [WebRTC - Video Call with SocketIO Nodejs]

[webrtc - video call with socketio nodejs]: https://www.bloggernepal.com/2021/05/webrtc-video-call-with-socketio-nodejs.html
